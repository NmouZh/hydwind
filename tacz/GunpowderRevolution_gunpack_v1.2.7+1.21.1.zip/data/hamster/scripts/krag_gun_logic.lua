local M = {}

function M.shoot(api)
    api:shootOnce(api:isShootingNeedConsumeAmmo())
end

function M.start_bolt(api)
    return true
end

function M.tick_bolt(api)
    -- 从data中获取拉栓所需的时间
    local total_bolt_time = api:getScriptParams().bolt_time * 1000
    if (total_bolt_time == nil) then
        return false
    end
    -- 获取并检查从开始拉栓到现在的时间
    if (api:getBoltTime() < total_bolt_time) then
        -- 还未到达所需时间时，返回true，使拉栓函数继续循环执行
        return true
    else
        -- 大于所需时间时也即是拉栓完成时
        -- 从弹匣中扣除一颗子弹，其返回值是成功扣除子弹的数量。
        if (api:removeAmmoFromMagazine(1) ~= 0) then
        -- 返回数量不为0则意味着成功扣除，弹匣中子弹数不为空，因此设置枪膛内具有子弹
            api:setAmmoInBarrel(true);
        end
        -- 返回false来结束拉栓函数循环
        return false
    end
end

function M.start_reload(api)
    -- Initialize cache that will be used in reload ticking
    local cache = {
        reloaded_count = 0,
        needed_count = api:getNeededAmmoAmount(),
        is_tactical = api:getReloadStateType() == TACTICAL_RELOAD_FEEDING,
        interrupted_time = -1,
    }
    api:cacheScriptData(cache)
    -- Return true to start ticking
    return true
end

local function getReloadTimingFromParam(param)
    -- Need to convert time from seconds to milliseconds
    local intro = param.intro * 1000
    local intro_empty = param.intro_empty * 1000
    local loop_1 = param.loop_1 * 1000
    local loop_2 = param.loop_2 * 1000
    local loop_3 = param.loop_3 * 1000
    local ending = param.ending * 1000
    local ending_empty = param.ending_empty * 1000
    local ending_empty_feed = param.ending_empty_feed * 1000
    local clip_load = param.clip_load * 1000
    local clip_load_feed = param.clip_load_feed * 1000
    local loop_1_feed = param.loop_1_feed * 1000
    local loop_2_feed = param.loop_2_feed * 1000
    local loop_3_feed = param.loop_3_feed * 1000
    -- Check if any timing is nil
    if (intro == nil or intro_empty == nil or loop_1 == nil or loop_2 == nil or loop_3 == nil or ending == nil or ending_empty == nil or ending_empty_feed == nil or clip_load == nil or clip_load_feed == nil or loop_1_feed == nil or loop_2_feed == nil or loop_3_feed == nil) then
        return nil
    end
    return intro, intro_empty, loop_1, loop_2, loop_3, ending, ending_empty, ending_empty_feed, clip_load, clip_load_feed, loop_1_feed, loop_2_feed, loop_3_feed
end

function M.tick_reload(api)
    -- Get all timings from script parameter in gun data
    local param = api:getScriptParams();
    local intro, intro_empty, loop_1, loop_2, loop_3, ending, ending_empty, ending_empty_feed, clip_load, clip_load_feed, loop_1_feed, loop_2_feed, loop_3_feed = getReloadTimingFromParam(param)
    -- Get reload time (The time from the start of reloading to the current time) from api
    local reload_time = api:getReloadTime()
    -- Get cache from api, it will be used to count loaded ammo, mark reload interruptions, etc.
    local cache = api:getCachedScriptData()
    local interrupted_time = cache.interrupted_time
    -- Handle interrupting reload
    if (cache.interrupted_time ~= -1) then
        local int_time = reload_time - cache.interrupted_time
        if (not cache.is_tactical) then
            if (int_time > ending_empty_feed) then
                if(not api:hasAmmoInBarrel()) then
                    if (api:removeAmmoFromMagazine(1) ~= 0) then
                        api:setAmmoInBarrel(true);
                    end
                end
            end
            if(int_time >= ending_empty) then
               return NOT_RELOADING, -1
            else
               return EMPTY_RELOAD_FINISHING, ending_empty - int_time
            end
        else
            if(int_time >= ending) then
               return NOT_RELOADING, -1
            else
                return TACTICAL_RELOAD_FINISHING, ending - int_time
            end
        end
    else
        if (not api:hasAmmoToConsume()) then
            interrupted_time = api:getReloadTime()
        end
    end

    local reloaded_count = cache.reloaded_count;
    -- Load the ammo into the magazine one by one
    if (reloaded_count >= 0) then
        local remainder = reloaded_count % 3
        local base_time = math.floor(reloaded_count / 3) * loop_3 +
        (remainder == 1 and loop_1 or (remainder == 2 and loop_2 or 0))

        if (cache.needed_count - reloaded_count >= 5 and api:getMagExtentLevel() == 1) then
            base_time = base_time + clip_load_feed
        else
            if ((cache.needed_count - reloaded_count) / 3 >= 1) then
                base_time = base_time + loop_3_feed
            elseif((cache.needed_count - reloaded_count) / 2 >= 1) then
                base_time = base_time + loop_2_feed
            else
                base_time = base_time + loop_1_feed
            end
        end

        if (not cache.is_tactical) then
            base_time = base_time + intro_empty
        else
            base_time = base_time + intro
        end

        while (base_time < reload_time) do
            if (reloaded_count > cache.needed_count) then
                break
            end
            if (cache.needed_count - reloaded_count >= 5 and api:getMagExtentLevel() == 1) then
                reloaded_count = reloaded_count + 5
                base_time = base_time + clip_load
                api:putAmmoInMagazine(api:isReloadingNeedConsumeAmmo() and api:consumeAmmoFromPlayer(5) or 5)
            else
                if ((cache.needed_count - reloaded_count) / 3 >= 1) then
                    base_time = base_time + loop_3
                    reloaded_count = reloaded_count + 3
                    api:consumeAmmoFromPlayer(3)
                    api:putAmmoInMagazine(3)
                elseif((cache.needed_count - reloaded_count) / 2 >= 1) then
                    base_time = base_time + loop_2
                    reloaded_count = reloaded_count + 2
                    api:consumeAmmoFromPlayer(2)
                    api:putAmmoInMagazine(2)
                else
                    base_time = base_time + loop_1
                    reloaded_count = reloaded_count + 1
                    api:consumeAmmoFromPlayer(1)
                    api:putAmmoInMagazine(1)
                end
            end
        end
    end

    -- Write back cache
    if (reloaded_count >= cache.needed_count) then
        interrupted_time = api:getReloadTime() - loop_1_feed + loop_1
    end
    cache.interrupted_time = interrupted_time
    cache.reloaded_count = reloaded_count
    api:cacheScriptData(cache)
    -- return reloadstate
    local total_time = cache.needed_count * loop_1
    if (not cache.is_tactical) then
        total_time = total_time + intro
        return EMPTY_RELOAD_FEEDING, total_time - reload_time
    else
        total_time = total_time + intro
        return TACTICAL_RELOAD_FEEDING, total_time - reload_time
    end
end

function M.interrupt_reload(api)
    local cache = api:getCachedScriptData()
    if (cache ~= nil and cache.interrupted_time == -1) then
        cache.interrupted_time = api:getReloadTime()
    end
end

return M